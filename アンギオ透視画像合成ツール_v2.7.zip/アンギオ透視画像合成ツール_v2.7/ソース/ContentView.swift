import SwiftUI
import AppKit
import UniformTypeIdentifiers

// MARK: - FileDocument（PNG保存用）
struct PNGDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.png] }
    var data: Data

    init(data: Data) { self.data = data }
    init(configuration: ReadConfiguration) throws {
        data = configuration.file.regularFileContents ?? Data()
    }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: data)
    }
}

// MARK: - Color Extension
extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let r, g, b: UInt64
        (r, g, b) = (int >> 16, int >> 8 & 0xFF, int & 0xFF)
        self.init(.sRGB, red: Double(r)/255, green: Double(g)/255, blue: Double(b)/255)
    }
}

private let cBgDark  = Color(hex: "0f1117")
private let cBgCard  = Color(hex: "1e2130")
private let cBgSec   = Color(hex: "1a1d27")
private let cAccent  = Color(hex: "4f8ef7")
private let cAccent2 = Color(hex: "7c6af7")
private let cSuccess = Color(hex: "34d399")
private let cTextPri = Color(hex: "e8eaf2")
private let cTextSec = Color(hex: "8b90a7")

// MARK: - 画像ユーティリティ
/// 元画像のピクセル寸法（NSImage.size は pt なのでピクセル単位で扱う）
func pixelSize(of image: NSImage) -> CGSize {
    var rect = CGRect(origin: .zero, size: image.size)
    if let cg = image.cgImage(forProposedRect: &rect, context: nil, hints: nil) {
        return CGSize(width: CGFloat(cg.width), height: CGFloat(cg.height))
    }
    return image.size
}

/// 正方形選択（元画像ピクセル座標・原点は左上）で切り出した画像を返す。nil ならそのまま
func croppedImage(_ image: NSImage?, to crop: CGRect?) -> NSImage? {
    guard let image else { return nil }
    guard let crop else { return image }
    var rect = CGRect(origin: .zero, size: image.size)
    guard let cg = image.cgImage(forProposedRect: &rect, context: nil, hints: nil) else { return image }
    let bounds = CGRect(x: 0, y: 0, width: CGFloat(cg.width), height: CGFloat(cg.height))
    let target = crop.integral.intersection(bounds)
    guard !target.isNull, target.width >= 1, target.height >= 1,
          let cut = cg.cropping(to: target) else { return image }
    return NSImage(cgImage: cut, size: NSSize(width: cut.width, height: cut.height))
}

/// アスペクト比を保って container に収めたときの表示矩形
func fittedRect(imageSize: CGSize, in container: CGSize) -> CGRect {
    guard imageSize.width > 0, imageSize.height > 0 else { return .zero }
    let scale = min(container.width / imageSize.width, container.height / imageSize.height)
    let w = imageSize.width * scale, h = imageSize.height * scale
    return CGRect(x: (container.width - w) / 2, y: (container.height - h) / 2, width: w, height: h)
}

/// 基点 a から p 方向へ、bounds 内に収まる正方形をつくる
func squareRect(from a: CGPoint, to p: CGPoint, bounds: CGSize) -> CGRect {
    let dx = p.x - a.x, dy = p.y - a.y
    let sx: CGFloat = dx < 0 ? -1 : 1
    let sy: CGFloat = dy < 0 ? -1 : 1
    let maxS = min(sx > 0 ? bounds.width - a.x : a.x,
                   sy > 0 ? bounds.height - a.y : a.y)
    let s = max(1, min(max(abs(dx), abs(dy)), max(1, maxS)))
    return CGRect(x: sx > 0 ? a.x : a.x - s,
                  y: sy > 0 ? a.y : a.y - s,
                  width: s, height: s)
}

/// macOS 13+ でのみカーソル形状を変える
struct HoverCursor: ViewModifier {
    let cursorFor: (CGPoint) -> NSCursor
    @ViewBuilder
    func body(content: Content) -> some View {
        if #available(macOS 13.0, *) {
            content.onContinuousHover { phase in
                switch phase {
                case .active(let point): cursorFor(point).set()
                case .ended: NSCursor.arrow.set()
                }
            }
        } else {
            content
        }
    }
}

// MARK: - 画像と選択範囲を1枚のCanvasに描画（レイアウトのズレを構造的に排除）
struct CropCanvasView: View {
    let image: NSImage
    let px: CGSize
    let crop: CGRect?
    let accent: Color

    var body: some View {
        Canvas { ctx, size in
            let disp = fittedRect(imageSize: px, in: size)
            guard disp.width > 0, disp.height > 0 else { return }
            ctx.draw(Image(nsImage: image), in: disp)

            guard let c = crop, px.width > 0 else { return }
            let k = disp.width / px.width
            let sel = CGRect(x: disp.minX + c.minX * k, y: disp.minY + c.minY * k,
                             width: c.width * k, height: c.height * k)

            // 選択範囲の外側を暗くする
            var outside = Path()
            outside.addRect(disp)
            outside.addRect(sel)
            ctx.fill(outside, with: .color(.black.opacity(0.55)), style: FillStyle(eoFill: true))

            // 3分割ガイド
            var grid = Path()
            for i in 1..<3 {
                let x = sel.minX + sel.width * CGFloat(i) / 3
                let y = sel.minY + sel.height * CGFloat(i) / 3
                grid.move(to: CGPoint(x: x, y: sel.minY)); grid.addLine(to: CGPoint(x: x, y: sel.maxY))
                grid.move(to: CGPoint(x: sel.minX, y: y)); grid.addLine(to: CGPoint(x: sel.maxX, y: y))
            }
            ctx.stroke(grid, with: .color(.white.opacity(0.35)), lineWidth: 1)

            // 枠
            var frame = Path(); frame.addRect(sel)
            ctx.stroke(frame, with: .color(accent), lineWidth: 2)

            // 四隅ハンドル
            var handles = Path()
            for pt in [CGPoint(x: sel.minX, y: sel.minY), CGPoint(x: sel.maxX, y: sel.minY),
                       CGPoint(x: sel.minX, y: sel.maxY), CGPoint(x: sel.maxX, y: sel.maxY)] {
                handles.addRect(CGRect(x: pt.x - 5, y: pt.y - 5, width: 10, height: 10))
            }
            ctx.fill(handles, with: .color(accent))
        }
    }
}

// MARK: - DropZoneView（ドラッグで正方形トリミング）
struct DropZoneView: View {
    @Binding var image: NSImage?
    @Binding var imageName: String
    @Binding var crop: CGRect?          // 元画像ピクセル座標（原点＝左上）
    let label: String
    let accentColor: Color
    var onChange: () -> Void

    @State private var isTargeted = false
    @State private var dragMode: DragMode = .none
    @State private var dragAnchor: CGPoint = .zero      // 新規／リサイズの固定点（画像px）
    @State private var dragStartCrop: CGRect = .zero    // 移動開始時の選択範囲

    private enum DragMode { case none, new, move, resize }
    private let handleHit: CGFloat = 11                 // 角ハンドルの当たり判定（表示pt）

    var body: some View {
        VStack(spacing: 8) {
            Text(label)
                .font(.system(size: 12, weight: .bold))
                .foregroundColor(accentColor)

            Button {
                openFilePicker()
            } label: {
                Text("📁  ファイルを選択")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(cTextPri)
                    .padding(.horizontal, 16).padding(.vertical, 7)
                    .background(cBgSec).cornerRadius(8)
                    .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.white.opacity(0.1), lineWidth: 1))
            }
            .buttonStyle(.plain)

            if image != nil {
                Text("画像の上をドラッグ → 正方形で切り出し（内側ドラッグで移動／角で拡大縮小）")
                    .font(.system(size: 10)).foregroundColor(cTextSec)
                    .multilineTextAlignment(.center)
            }

            ZStack {
                RoundedRectangle(cornerRadius: 12)
                    .fill(isTargeted ? accentColor.opacity(0.2) : cBgCard.opacity(0.6))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .strokeBorder(
                                isTargeted ? accentColor : accentColor.opacity(0.4),
                                style: StrokeStyle(lineWidth: 2, dash: [6, 4])
                            )
                    )

                if let img = image {
                    imageEditor(img)
                        .padding(8)
                } else {
                    VStack(spacing: 8) {
                        Image(systemName: "photo.badge.plus")
                            .font(.system(size: 34)).foregroundColor(accentColor.opacity(0.6))
                        Text("ここにドラッグ＆ドロップ")
                            .font(.system(size: 12, weight: .medium)).foregroundColor(cTextSec)
                        Text("または上のボタンで選択")
                            .font(.system(size: 11)).foregroundColor(cTextSec.opacity(0.7))
                    }
                }
            }
            .frame(height: 260)
            .onDrop(of: [.fileURL], isTargeted: $isTargeted, perform: handleDrop)

            if !imageName.isEmpty {
                Text("✓ \(imageName)")
                    .font(.system(size: 10)).foregroundColor(cSuccess)
                    .lineLimit(1).truncationMode(.middle)
            }

            if image != nil {
                HStack(spacing: 8) {
                    if let c = crop {
                        Text("切り出し \(Int(c.width)) × \(Int(c.height)) px（位置 \(Int(c.minX)), \(Int(c.minY))）")
                            .font(.system(size: 10)).foregroundColor(cTextSec)
                        Button {
                            crop = nil
                            onChange()
                        } label: {
                            Text("選択解除")
                                .font(.system(size: 10))
                                .foregroundColor(cTextSec)
                                .padding(.horizontal, 10).padding(.vertical, 3)
                                .overlay(Capsule().stroke(Color.white.opacity(0.15), lineWidth: 1))
                        }
                        .buttonStyle(.plain)
                    } else if let img = image {
                        let px = pixelSize(of: img)
                        Text("未選択 — 画像全体を使用（\(Int(px.width)) × \(Int(px.height)) px）")
                            .font(.system(size: 10)).foregroundColor(cTextSec)
                    }
                }
            }
        }
        .padding(14).background(cBgCard).cornerRadius(16)
    }

    // MARK: 画像＋選択範囲の描画とドラッグ操作
    @ViewBuilder
    private func imageEditor(_ img: NSImage) -> some View {
        let px = pixelSize(of: img)
        GeometryReader { geo in
            let disp = fittedRect(imageSize: px, in: geo.size)
            let scale = px.width > 0 ? disp.width / px.width : 1

            CropCanvasView(image: img, px: px, crop: crop, accent: accentColor)
                .contentShape(Rectangle())
                .modifier(HoverCursor { point in
                    guard let c = crop else { return .crosshair }
                    let sel = viewRect(of: c, disp: disp, scale: scale)
                    if fixedCorner(for: point, sel: sel) != nil { return .crosshair }
                    return sel.contains(point) ? .openHand : .crosshair
                })
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .onChanged { value in
                            let start = imagePoint(value.startLocation, disp: disp, scale: scale, px: px)
                            let now   = imagePoint(value.location,      disp: disp, scale: scale, px: px)

                            if dragMode == .none {
                                let sel = crop.map { viewRect(of: $0, disp: disp, scale: scale) }
                                if let sel, let fixed = fixedCorner(for: value.startLocation, sel: sel) {
                                    dragMode = .resize
                                    dragAnchor = imagePoint(fixed, disp: disp, scale: scale, px: px)
                                } else if let c = crop, c.contains(start) {
                                    dragMode = .move
                                    dragStartCrop = c
                                    dragAnchor = start
                                } else {
                                    dragMode = .new
                                    dragAnchor = start
                                }
                            }

                            switch dragMode {
                            case .move:
                                let nx = min(max(0, dragStartCrop.minX + (now.x - dragAnchor.x)), px.width  - dragStartCrop.width)
                                let ny = min(max(0, dragStartCrop.minY + (now.y - dragAnchor.y)), px.height - dragStartCrop.height)
                                crop = CGRect(x: nx, y: ny, width: dragStartCrop.width, height: dragStartCrop.height)
                            case .new, .resize:
                                crop = squareRect(from: dragAnchor, to: now, bounds: px)
                            case .none:
                                break
                            }
                            onChange()
                        }
                        .onEnded { _ in
                            if dragMode == .new, let c = crop, c.width < 8 {
                                crop = nil          // 選択範囲の外をクリックしただけ → 解除
                            } else if let c = crop {
                                crop = c.integral
                            }
                            dragMode = .none
                            onChange()
                        }
                )
        }
    }

    // 画像px ↔ 表示座標
    private func viewRect(of rect: CGRect, disp: CGRect, scale: CGFloat) -> CGRect {
        CGRect(x: disp.minX + rect.minX * scale, y: disp.minY + rect.minY * scale,
               width: rect.width * scale, height: rect.height * scale)
    }

    private func imagePoint(_ point: CGPoint, disp: CGRect, scale: CGFloat, px: CGSize) -> CGPoint {
        guard scale > 0 else { return .zero }
        return CGPoint(x: min(max(0, (point.x - disp.minX) / scale), px.width),
                       y: min(max(0, (point.y - disp.minY) / scale), px.height))
    }

    private func corners(of rect: CGRect) -> [CGPoint] {
        [CGPoint(x: rect.minX, y: rect.minY), CGPoint(x: rect.maxX, y: rect.minY),
         CGPoint(x: rect.minX, y: rect.maxY), CGPoint(x: rect.maxX, y: rect.maxY)]
    }

    /// 角ハンドルに当たっていれば、その対角（固定点）を表示座標で返す
    private func fixedCorner(for point: CGPoint, sel: CGRect) -> CGPoint? {
        let pairs: [(CGPoint, CGPoint)] = [
            (CGPoint(x: sel.minX, y: sel.minY), CGPoint(x: sel.maxX, y: sel.maxY)),
            (CGPoint(x: sel.maxX, y: sel.minY), CGPoint(x: sel.minX, y: sel.maxY)),
            (CGPoint(x: sel.minX, y: sel.maxY), CGPoint(x: sel.maxX, y: sel.minY)),
            (CGPoint(x: sel.maxX, y: sel.maxY), CGPoint(x: sel.minX, y: sel.minY))
        ]
        for (corner, opposite) in pairs
        where abs(corner.x - point.x) <= handleHit && abs(corner.y - point.y) <= handleHit {
            return opposite
        }
        return nil
    }

    // MARK: ファイル読み込み
    private func openFilePicker() {
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [.png, .jpeg, .bmp, .tiff, .gif]
        panel.allowsMultipleSelection = false
        if panel.runModal() == .OK, let url = panel.url { load(from: url) }
    }

    private func handleDrop(providers: [NSItemProvider]) -> Bool {
        guard let provider = providers.first else { return false }
        provider.loadItem(forTypeIdentifier: UTType.fileURL.identifier, options: nil) { item, _ in
            var fileURL: URL?
            if let url = item as? URL { fileURL = url }
            else if let data = item as? Data { fileURL = URL(dataRepresentation: data, relativeTo: nil) }
            else if let str = item as? String { fileURL = URL(string: str) }
            if let fileURL { DispatchQueue.main.async { load(from: fileURL) } }
        }
        return true
    }

    private func load(from url: URL) {
        guard let img = NSImage(contentsOf: url) else { return }
        image = img
        imageName = url.lastPathComponent
        crop = nil
        onChange()
    }
}

// MARK: - ParamField
struct ParamField: View {
    let label: String; @Binding var value: String
    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(label).font(.system(size: 9)).foregroundColor(cTextSec)
            TextField("", text: $value)
                .textFieldStyle(.plain)
                .font(.system(size: 13, design: .monospaced)).foregroundColor(cTextPri)
                .padding(.horizontal, 10).padding(.vertical, 7)
                .background(cBgSec).cornerRadius(8)
                .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.white.opacity(0.07), lineWidth: 1))
        }
    }
}

// MARK: - ContentView
struct ContentView: View {
    @State private var image1: NSImage? = nil
    @State private var image2: NSImage? = nil
    @State private var name1 = ""; @State private var name2 = ""
    @State private var crop1: CGRect? = nil
    @State private var crop2: CGRect? = nil

    @State private var canvasW = "1190"; @State private var canvasH = "600"
    @State private var imgSize = "580"
    @State private var cx1 = "300"; @State private var cx2 = "890"; @State private var cy = "300"

    @State private var statusMsg     = "2枚の画像を選択してください"
    @State private var resultImage: NSImage? = nil
    @State private var resultCG: CGImage? = nil
    @State private var exportDoc: PNGDocument? = nil
    @State private var showExporter  = false
    @State private var exportName    = "アンギオ合成.png"

    var canGenerate: Bool { image1 != nil && image2 != nil }
    var canSave:     Bool { resultCG != nil }

    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack(spacing: 14) {
                Text("🫀").font(.title2)
                VStack(alignment: .leading, spacing: 1) {
                    Text("アンギオ透視画像合成ツール")
                        .font(.system(size: 16, weight: .bold)).foregroundColor(cTextPri)
                    Text("RAO, LAO画像からレポート用合成画像を作成、保存")
                        .font(.system(size: 11)).foregroundColor(cTextSec)
                }
                Spacer()
            }
            .padding(.horizontal, 24).padding(.vertical, 14).background(cBgSec)

            ScrollView {
                VStack(spacing: 16) {
                    // Drop zones
                    HStack(alignment: .top, spacing: 16) {
                        DropZoneView(image: $image1, imageName: $name1, crop: $crop1,
                                     label: "🔵  画像 1 — 左側配置",
                                     accentColor: cAccent, onChange: refresh)
                        DropZoneView(image: $image2, imageName: $name2, crop: $crop2,
                                     label: "🟣  画像 2 — 右側配置",
                                     accentColor: cAccent2, onChange: refresh)
                    }

                    // 合成結果（2枚そろった時点で自動生成・ドラッグに即追従）
                    if let preview = resultImage {
                        VStack(alignment: .leading, spacing: 10) {
                            HStack(spacing: 10) {
                                Circle().fill(cSuccess).frame(width: 8, height: 8)
                                Text("合成結果")
                                    .font(.system(size: 14, weight: .semibold)).foregroundColor(cTextPri)
                                Spacer()
                                Button(action: save) {
                                    Text("⬇️　PNG でダウンロード")
                                        .font(.system(size: 12, weight: .medium))
                                        .foregroundColor(cTextPri)
                                        .padding(.horizontal, 16).padding(.vertical, 8)
                                        .background(cBgSec).cornerRadius(8)
                                        .overlay(RoundedRectangle(cornerRadius: 8)
                                            .stroke(Color.white.opacity(0.1), lineWidth: 1))
                                }
                                .buttonStyle(.plain)
                                .disabled(!canSave)
                            }
                            Image(nsImage: preview)
                                .resizable().scaledToFit()
                                .cornerRadius(10).frame(maxHeight: 340)
                        }
                        .padding(16).background(cBgCard).cornerRadius(16)
                    }

                    // ステータス（2枚そろうまでの案内のみ）
                    if !canGenerate {
                        HStack(spacing: 8) {
                            Text(statusMsg).font(.system(size: 12)).foregroundColor(cTextSec)
                            Spacer()
                        }
                        .padding(.horizontal, 14).padding(.vertical, 10)
                        .background(cBgSec).cornerRadius(10)
                    }

                    // パラメータ
                    VStack(alignment: .leading, spacing: 10) {
                        Text("⚙️　パラメータ設定")
                            .font(.system(size: 11, weight: .bold)).foregroundColor(cTextSec)
                        HStack(spacing: 10) {
                            ParamField(label: "キャンバス幅", value: $canvasW)
                            ParamField(label: "キャンバス高さ", value: $canvasH)
                            ParamField(label: "画像サイズ", value: $imgSize)
                        }
                        HStack(spacing: 10) {
                            ParamField(label: "画像1 中心X（左）", value: $cx1)
                            ParamField(label: "画像2 中心X（右）", value: $cx2)
                            ParamField(label: "中心Y（共通）", value: $cy)
                        }
                    }
                    .padding(16).background(cBgCard).cornerRadius(16)
                }
                .padding(20)
            }
        }
        .onChange(of: canvasW) { _, _ in refresh() }
        .onChange(of: canvasH) { _, _ in refresh() }
        .onChange(of: imgSize) { _, _ in refresh() }
        .onChange(of: cx1)     { _, _ in refresh() }
        .onChange(of: cx2)     { _, _ in refresh() }
        .onChange(of: cy)      { _, _ in refresh() }
        .frame(minWidth: 820, minHeight: 720)
        .background(cBgDark)
        // SwiftUI標準の保存ダイアログ（フリーズしない）
        .fileExporter(
            isPresented: $showExporter,
            document: exportDoc,
            contentType: .png,
            defaultFilename: exportName
        ) { result in
            switch result {
            case .success(let url):
                statusMsg = "✅  保存完了: \(url.lastPathComponent)"
            case .failure(let error):
                statusMsg = "❌  保存失敗: \(error.localizedDescription)"
            }
        }
    }

    // MARK: - 画像／選択範囲／パラメータが変わったとき（自動合成）
    private func refresh() {
        guard canGenerate else {
            resultImage = nil; resultCG = nil
            statusMsg = image1 == nil ? "画像1を選択してください" : "画像2を選択してください"
            return
        }
        generate()
    }

    // MARK: - 合成（プレビューのみ作成。PNG符号化は保存時）
    private func generate() {
        guard let src1 = croppedImage(image1, to: crop1),
              let src2 = croppedImage(image2, to: crop2) else { return }
        guard let cw = Int(canvasW), let ch = Int(canvasH), let is_ = Int(imgSize),
              let x1 = Int(cx1), let x2 = Int(cx2), let yc = Int(cy),
              cw > 0, ch > 0, is_ > 0 else {
            statusMsg = "❌  パラメータに不正な値があります"; return
        }

        guard let cg = composite(
            img1: src1, img2: src2,
            cw: cw, ch: ch, imgSize: is_,
            cx1: x1, cx2: x2, cy: yc
        ) else {
            statusMsg = "❌  合成に失敗しました"; return
        }

        resultCG    = cg
        resultImage = NSImage(cgImage: cg, size: NSSize(width: cw, height: ch))
        statusMsg   = ""
    }

    // MARK: - 保存（このときだけPNGに符号化）
    private func save() {
        guard let cg = resultCG, let data = pngData(from: cg) else {
            statusMsg = "❌  PNG生成に失敗しました"; return
        }
        let fmt = DateFormatter(); fmt.dateFormat = "yyyyMMdd_HHmmss"
        exportName = "アンギオ合成_\(fmt.string(from: Date())).png"
        exportDoc  = PNGDocument(data: data)
        showExporter = true
    }

    private func pngData(from cg: CGImage) -> Data? {
        let mutableData = CFDataCreateMutable(nil, 0)!
        guard let dest = CGImageDestinationCreateWithData(
            mutableData, UTType.png.identifier as CFString, 1, nil
        ) else { return nil }
        CGImageDestinationAddImage(dest, cg, nil)
        guard CGImageDestinationFinalize(dest) else { return nil }
        return mutableData as Data
    }

    // MARK: - Core Graphics 合成
    private func composite(
        img1: NSImage, img2: NSImage,
        cw: Int, ch: Int, imgSize: Int,
        cx1: Int, cx2: Int, cy: Int
    ) -> CGImage? {
        let cs = CGColorSpaceCreateDeviceRGB()
        guard let ctx = CGContext(
            data: nil, width: cw, height: ch,
            bitsPerComponent: 8, bytesPerRow: 0, space: cs,
            bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
        ) else { return nil }

        ctx.setFillColor(CGColor(red: 0.8, green: 1.0, blue: 0.8, alpha: 1.0)) // #ccffcc
        ctx.fill(CGRect(x: 0, y: 0, width: cw, height: ch))
        ctx.interpolationQuality = .high

        func draw(_ nsImg: NSImage, cx: Int, cy: Int) {
            var r = CGRect(origin: .zero, size: nsImg.size)
            guard let cg = nsImg.cgImage(forProposedRect: &r, context: nil, hints: nil) else { return }
            let sw = CGFloat(cg.width), sh = CGFloat(cg.height)
            guard sw > 0, sh > 0 else { return }
            let sc = min(CGFloat(imgSize) / sw, CGFloat(imgSize) / sh)
            let dw = sw * sc; let dh = sh * sc
            let x = CGFloat(cx) - dw / 2
            let y = CGFloat(ch) - CGFloat(cy) - dh / 2   // CG座標は下が原点
            ctx.draw(cg, in: CGRect(x: x, y: y, width: dw, height: dh))
        }

        draw(img1, cx: cx1, cy: cy)
        draw(img2, cx: cx2, cy: cy)

        return ctx.makeImage()
    }
}
